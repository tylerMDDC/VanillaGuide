VanillaGuide
============
VanillaGuide aim to cover the hole for an in-game guide for Vanilla WoW. The AddOn features:

    Step-by-Step Zone Guides (from Joana and Brian Kopps work)
    Hints and Tips for various Quests
    MetaMapBWP Integration

> **NOTE:**
>
> - This Addon is developed for WoW 1.12.1 (toc 11200), also known as Vanilla WoW 
>

Credits
=======
Well, thank you Joana/Mancow, you ruined my life with WoW, but I love you anyway.

and here're the links to the REAL guide:

    http://www.joanasworld.com/meet_joana_mancow.html
    http://www.joanasworld.com/azeroth.htm
    http://www.joanasworld.com/Joanas1-60Guide.pdf


Donations
=========
If you would like to support this project, you may donate to our development fund via Paypal.

[![Donate](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=LSR84M2ZJEPJS)

Any funds donated will be used to help further development on this project, by purchasing equipment, etc.

We are always looking for more volunteers to help with coding, customizations, etc, so feel free to contact us.

Thank you.
